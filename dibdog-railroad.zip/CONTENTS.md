# Dibdog Railroad Diagrams — handoff

## Contents
- `railroad-diagrams.md` — the project doc. The whole plan.

## Where to start
Read `railroad-diagrams.md` top to bottom, then begin with the **extractor**, not the renderer.

## Build order (do not reorder)
1. **Extractor** — inside Scryer, read the loaded `grammar/dcg.pl` via `clause/2` (not by parsing source text). Emit railroad-ready EBNF. Spike pre- vs post-DCG-expansion clause reading early (open question 4) — pick whichever makes the `_list`/`_list_rest` → `OneOrMore` fold reliable. Fail loudly on any unrecognised clause shape; never skip silently.
2. **Equivalence gate** — get this green before drawing anything. Corpus replay + differential fuzzing (DCG-generated sentences parse under the EBNF, and vice versa). A diagram set that hasn't passed the gate is not published.
3. **Renderer** — only after the gate passes. EBNF → SVG per rule via the tabatkins `railroad-diagrams` lineage, then a cross-linked `index.html` in the SQLite "factored" style.

## The one risky transform
The `foo_list` / `foo_list_rest` + empty-base idiom must collapse to a single `OneOrMore(foo, separator=',')`. It's the only heuristic in the extractor and the main thing the gate validates. If a fuzz sentence diverges, suspect this first.

## Open questions for the human (in the doc)
Single mega-page vs per-statement pages; fuzzer seed source; `identifier` terminal granularity; clause-reading strategy.
